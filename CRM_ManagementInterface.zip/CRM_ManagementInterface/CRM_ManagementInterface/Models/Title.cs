﻿namespace CRM_ManagementInterface.Models
{
    public class Title
    {
       
            public int TitleId { get; set; }
            public string? TitleName { get; set; }
            
        
    }
}
