﻿namespace CRM_ManagementInterface.Models
{
    public class ClientType
    {
        public int ClientTypeId { get; set; }
        public string? ClientTypeName { get; set; }
        
    }
}
